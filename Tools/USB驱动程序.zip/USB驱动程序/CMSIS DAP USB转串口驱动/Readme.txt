1、windows 10系统不需要安装此驱动。
2、如使用windows 7操作系统，请在设备管理器中，指定驱动文件位置到"CMSIS-DAP_Update.INF"文件所在的路径进行安装。